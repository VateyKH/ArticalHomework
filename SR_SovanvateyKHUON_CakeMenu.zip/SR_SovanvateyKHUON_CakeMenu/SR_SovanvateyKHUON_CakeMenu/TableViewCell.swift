//
//  TableViewCell.swift
//  SR_SovanvateyKHUON_CakeMenu
//
//  Created by otey on 11/23/16.
//  Copyright © 2016 tey. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    @IBOutlet weak var mainImageView: UIImageView!
    @IBOutlet weak var cakeNameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

   }
